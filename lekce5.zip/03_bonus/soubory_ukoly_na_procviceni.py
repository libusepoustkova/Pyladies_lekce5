"""
Otevřete jeden soubor pro čtení, druhý pro zápis.

1.Do druhého souboru přendejte obsah prvního souboru - samozřejmě programem v pythonu

2.Do druhého souboru přendejte obsah prvního souboru ale všechna písmena převeďte na velká

3.Do druhého souboru přendejte každou sudou řádku.

4.Do druhého souboru napište, kolik znaků má každá řádka.

5.Do druhého souboru napište kolik nebílých znaků má každá řádka

6.Do druhého souboru napiště počet samohlásek v textu každé řádky

7.Kolik odstavců soubor obsahuje?


