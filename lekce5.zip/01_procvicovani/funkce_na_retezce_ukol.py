# Napis funkci, ktera prevede text na velka pismena.
def upper_char(retezec):
    pass


# Napis funkci, ktera pocita pocet znaku v retezci.
def count_char(retezec):
    pass


# Napis funcki, ktera pocita pocet mezer v retezci
def count_spaces(retezec):
    pass


# Napis funcki, ktera pocita pocet "samohlasek"
def count_aeiou(retezec):
    pass

# Napis funkci, ktera vlozi retezec doprostred jineho retezce.
def string_in_string(ret, retvloz):
    pass


# Napis funkci, ktera obrati retezec
def reverse_string(retezec):
    pass

#
retezec_znaku = 'pokus'
print(reverse_string(retezec_znaku))
print(upper_char(retezec_znaku))
print(count_char(retezec_znaku))
print(count_spaces(retezec_znaku))
print(count_aeiou(retezec_znaku))
print(string_in_string(retezec_znaku, 'ahoj'))